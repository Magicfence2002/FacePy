import setuptools

setuptools.setup(
    name='FacePy',
    version='0.0.1',
    packages=[''],
    url='',
    license='Sanjay-2002',
    author='Sanjay T',
    author_email='sanjayipscoc@gmail.com',
    description='...'
)
